    $("[data-toggle=tooltip]").tooltip();
});