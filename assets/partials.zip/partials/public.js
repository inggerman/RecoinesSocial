'use strict';

angular.module('myApp.public', [])

.controller('PublicCtrl', ['$scope','$http','Authentication',function($scope,$http,Authentication) {


	io.socket.on('roompost',function(message){
		console.log(message);
		console.log(message.added.publicacion);
		switch(message.verb){

			case 'addedTo':
				$scope.posts.push(message.added);
				$scope.$apply();
				break;

		}
		
	});
	$scope.datos={};
	$scope.datos.iduser="";
	$scope.datos.username="";
	$scope.datos.post="";
	$scope.po=[];
	
	$scope.datos.idroom="";

	$scope.llenar=function(){
		io.socket.get('/getpost',{iduser:$scope.datos.iduser},function(data){
			for(var i=0;i<data.data.length;i++){
				for(var j=0;j<data.data[i].publi.length;j++){

					$scope.po.push(data.data[i].publi[j]);
					$scope.$apply();
					console.log(data.data[i].publi[j]);
					
				}
			}	
			$scope.posts=$scope.po;
			$scope.$apply();
			console.log($scope.posts);
			console.log(data);
			// console.log(data.data.length);
			// console.log(data.data.publi.length);
			$scope.posts=data;
			console.log(data.data[0].publi[0]);
		});
	}


	$scope.accion=function(){
		io.socket.get('/subfriend',$scope.datos,function(data){
			console.log($scope.datos.iduser);
			console.log(data);
		});
	};
	

	$scope.postear=function(){
		io.socket.get('/crearpost',$scope.datos,function(data){
		console.log($scope.iduser);
		console.log(data);
	});
	};

}]);