/**
 * EdificiosController
 *
 * @description :: Server-side logic for managing edificios
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

