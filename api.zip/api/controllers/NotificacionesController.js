/**
 * NotificacionesController
 *
 * @description :: Server-side logic for managing notificaciones
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

