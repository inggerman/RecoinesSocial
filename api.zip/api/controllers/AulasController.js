/**
 * AulasController
 *
 * @description :: Server-side logic for managing aulas
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

