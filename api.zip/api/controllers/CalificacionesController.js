/**
 * CalificacionesController
 *
 * @description :: Server-side logic for managing calificaciones
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

