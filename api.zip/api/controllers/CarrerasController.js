/**
 * CarreraController
 *
 * @description :: Server-side logic for managing carreras
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

