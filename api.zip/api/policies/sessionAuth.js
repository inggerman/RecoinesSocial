// api/policies/sessionAuth.js

module.exports = require('sails-auth/api/policies/sessionAuth');
