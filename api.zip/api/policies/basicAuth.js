// api/policies/basicAuth.js

module.exports = require('sails-auth/api/policies/basicAuth');
