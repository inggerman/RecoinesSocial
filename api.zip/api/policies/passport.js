// api/policies/passport.js

module.exports = require('sails-auth/api/policies/passport');
